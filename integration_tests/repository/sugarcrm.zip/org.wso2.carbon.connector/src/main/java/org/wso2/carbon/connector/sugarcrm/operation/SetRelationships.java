package org.wso2.carbon.connector.sugarcrm.operation;

import java.util.Iterator;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.util.AXIOMUtil;
import org.apache.axiom.soap.SOAPBody;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.synapse.MessageContext;
import org.wso2.carbon.connector.core.AbstractConnector;
import org.wso2.carbon.connector.core.Connector;
import org.wso2.carbon.connector.core.util.ConnectorUtils;
import org.wso2.carbon.connector.sugarcrm.util.SugarCRMUtil;

public class SetRelationships extends AbstractConnector implements Connector {

    @SuppressWarnings("unchecked")
    public void connect(MessageContext messageContext) {
		try {
		    
		    SOAPEnvelope envelope = messageContext.getEnvelope();
		    SOAPBody body = envelope.getBody();
		    
		    Iterator<OMElement> bodyChildElements = body.getChildrenWithLocalName("set_relationships");
		    
		    if (bodyChildElements.hasNext()) {
		    	
		    	OMElement bodyElement = bodyChildElements.next();
		    	Iterator<OMElement> childElements = bodyElement.getChildrenWithLocalName("set_relationship_list");
		    	
		    	if (childElements.hasNext()) {
		    		
		    				    		
		    		OMElement childElement = childElements.next();
			    	String strSobject = (String) ConnectorUtils.lookupTemplateParamater(messageContext,"relationshipLists");
			    	
			    	
				    OMElement sObjects = AXIOMUtil.stringToOM(strSobject);				    
				    Iterator<OMElement> sObject = sObjects.getChildElements();
				    
				    
				    while (sObject.hasNext()) {
				    	OMElement nameValueListsElement = sObject.next();				    	
				    	childElement.addChild(nameValueListsElement);
				    	
				    }
		    	}
		    } 
		} catch (Exception e) {
		    System.out.println("Exception : " + SugarCRMUtil.getStackTraceAsString(e));
		}
    }
}