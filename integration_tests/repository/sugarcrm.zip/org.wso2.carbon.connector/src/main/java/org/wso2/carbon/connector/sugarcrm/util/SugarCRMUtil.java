package org.wso2.carbon.connector.sugarcrm.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.synapse.MessageContext;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;

/**
 * This class contains utility functions used for SugarCRM connector.
 */
public class SugarCRMUtil {
	
    public OMElement getItemElement(OMFactory omFactory, MessageContext messageContext, 
    		OMElement childElement, String strObject) {
    	
	    String[] strArray = strObject.split("\n");
	    List<String> itemList = new ArrayList<String>();
	    
	    for (int i=0; i<strArray.length; i++) {
			if (! strArray[i].trim().equals("")) {
			    itemList.add(strArray[i].trim());
			}
	    }
	    
	    //assume the child element name is item and soap request need to be sent as item
	    for (int n=0; n<itemList.size(); n++) {
	        OMElement itemElement = omFactory.createOMElement("item", null);
	        itemElement.addChild(omFactory.createOMText(itemList.get(n)));
	        childElement.addChild(itemElement);
	    }
		return childElement;
    }
    
    public static String getStackTraceAsString(Throwable e) {
    	StringWriter sw = new StringWriter();
    	PrintWriter pw = new PrintWriter(sw);
    	e.printStackTrace(pw);
    	return sw.toString();
    }
    
}
