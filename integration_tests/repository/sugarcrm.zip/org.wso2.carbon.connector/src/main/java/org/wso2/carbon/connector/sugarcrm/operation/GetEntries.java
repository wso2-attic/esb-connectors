package org.wso2.carbon.connector.sugarcrm.operation;

import java.util.Iterator;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.soap.SOAPBody;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.synapse.MessageContext;
import org.wso2.carbon.connector.core.AbstractConnector;
import org.wso2.carbon.connector.core.ConnectException;
import org.wso2.carbon.connector.core.Connector;
import org.wso2.carbon.connector.core.util.ConnectorUtils;
import org.wso2.carbon.connector.sugarcrm.util.SugarCRMUtil;

public class GetEntries extends AbstractConnector implements Connector {

	@SuppressWarnings({ "unchecked", "static-access" })
	public void connect(MessageContext messageContext) throws ConnectException {
		
		SOAPEnvelope envelope = messageContext.getEnvelope();
		OMFactory omFactory = OMAbstractFactory.getOMFactory();
		SOAPBody body = envelope.getBody();
		
		//soap request method name
		Iterator<OMElement> bodyChildElements = body.getChildrenWithLocalName("get_entries");
		
		try {
			OMElement bodyElement = bodyChildElements.next();
			
			//soap request array element name - id
			Iterator<OMElement> childElementsId = bodyElement.getChildrenWithLocalName("ids");
			
			if (childElementsId.hasNext()) {
				OMElement childElementId = childElementsId.next();
				
				//data field name 
			    String strobject = (String) ConnectorUtils.lookupTemplateParamater(messageContext, "ids");
			    (new SugarCRMUtil()).getItemElement(omFactory, messageContext, childElementId, strobject);
			}
			
			
			//soap request array element name - select_fields
			Iterator<OMElement> childElementsField = bodyElement.getChildrenWithLocalName("select_fields");
			
			if (childElementsField.hasNext()) {
				OMElement childElementField = childElementsField.next();
				
				//data field name 
			    String strobject = (String) ConnectorUtils.lookupTemplateParamater(messageContext, "selectFields");
			    (new SugarCRMUtil()).getItemElement(omFactory, messageContext, childElementField, strobject);
			}
				
			
		} catch(Exception e) {
			(new SugarCRMUtil()).getStackTraceAsString(e);
		}
	}
}
