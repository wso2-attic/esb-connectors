package org.wso2.carbon.connector.sugarcrm.operation;

import java.util.Iterator;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.soap.SOAPBody;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.synapse.MessageContext;
import org.wso2.carbon.connector.core.AbstractConnector;
import org.wso2.carbon.connector.core.ConnectException;
import org.wso2.carbon.connector.core.Connector;
import org.wso2.carbon.connector.core.util.ConnectorUtils;
import org.wso2.carbon.connector.sugarcrm.util.SugarCRMUtil;

public class GetEntryList extends AbstractConnector implements Connector {

	@SuppressWarnings({ "unchecked", "static-access" })
	public void connect(MessageContext messageContext) throws ConnectException {
		
		SOAPEnvelope envelope = messageContext.getEnvelope();
		OMFactory omFactory = OMAbstractFactory.getOMFactory();
		SOAPBody body = envelope.getBody();
		
		//soap request method name
		Iterator<OMElement> bodyChildElements = body.getChildrenWithLocalName("get_entry_list");
		
		try {
			OMElement bodyElement = bodyChildElements.next();
			
			//soap request array element name
			Iterator<OMElement> childElements = bodyElement.getChildrenWithLocalName("select_fields");
			
			if (childElements.hasNext()) {
				OMElement childElement = childElements.next();
				
				//data field name 
			    String strobject = (String) ConnectorUtils.lookupTemplateParamater(messageContext, "selectFields");
			    (new SugarCRMUtil()).getItemElement(omFactory, messageContext, childElement, strobject);
			}
			
		} catch(Exception e) {
			(new SugarCRMUtil()).getStackTraceAsString(e);
		}
	}
}
