package org.wso2.carbon.connector.sugarcrm.operation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.util.AXIOMUtil;
import org.apache.axiom.soap.SOAPBody;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.synapse.MessageContext;
import org.wso2.carbon.connector.core.AbstractConnector;
import org.wso2.carbon.connector.core.Connector;
import org.wso2.carbon.connector.core.util.ConnectorUtils;
import org.wso2.carbon.connector.sugarcrm.util.SugarCRMUtil;

public class SetEntry extends AbstractConnector implements Connector {

    @SuppressWarnings("unchecked")
    public void connect(MessageContext messageContext) {

	try {
	    
	    SOAPEnvelope envelope = messageContext.getEnvelope();
	    OMFactory fac = OMAbstractFactory.getOMFactory();
	    SOAPBody body = envelope.getBody();
	    
	    Iterator<OMElement> bodyChildElements = body.getChildrenWithLocalName("set_entry");
	    
	    if (bodyChildElements.hasNext()) {
		
		OMElement bodyElement = bodyChildElements.next();
		Iterator<OMElement> childElements = bodyElement.getChildrenWithLocalName("name_value_list");
		
		if (childElements.hasNext()) {
		    
		    OMElement childElement = childElements.next();
		    String strSobject = (String) ConnectorUtils.lookupTemplateParamater(messageContext,"nameValueList");
		    
		    String[] strArray = strSobject.split("\n");
		    List<String> itemList = new ArrayList<String>();
		    
		    for (int i = 0; i < strArray.length; i++) {
			if (!strArray[i].trim().equals("")) {
			    itemList.add(strArray[i].trim());
			}
		    }
		    
		    OMElement sObjects = AXIOMUtil.stringToOM(strSobject);
		    Iterator<OMElement> sObject = sObjects.getChildElements();
		    
		    while (sObject.hasNext()) {
			
			OMElement currentElement = sObject.next();
			OMNamespace omNsurn = fac.createOMNamespace("http://www.sugarcrm.com/sugarcrm", "sug");
			OMElement newElement = fac.createOMElement("name_value", omNsurn);
			
			// Create children
			Iterator<OMElement> nameAndValueItems = currentElement.getChildElements();
			
			while (nameAndValueItems.hasNext()) {
			    
			    OMElement item = nameAndValueItems.next();
			    
			    if (item.getLocalName().equals("name")) {
				newElement.addChild(item);
			    } else if (item.getLocalName().equals("value")) {
				newElement.addChild(item);
			    }
			    
			}
			
			childElement.addChild(newElement);
			
		    }
		    
		}
		
	    }
	    
	} catch (Exception e) {
	    System.out.println("Exception : " + SugarCRMUtil.getStackTraceAsString(e));
	}
	
    }
    
}
